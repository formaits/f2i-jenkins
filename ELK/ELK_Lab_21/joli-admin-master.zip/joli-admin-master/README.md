# Joli

Joli is a free admin template/Dashboard/Web App based on Angular JS. Its is responsive template means it is compatible with smart devices like tablet and phones as well.It is very easy to use and customize according to various requirements. Main Features:

- Angular JS Bootstrap 3.x
- Retina Ready
- Less used
- Smooth Css3 Animation
- Pure Css3 Menu
- FontAwesome Icons
- Parallax sections
- Working Contact Form
- Build with Sass (Compass) and Css
- Unlimited Color changing just one variable on SASS
- SEO ready
- Responsive for all devices
- Easy customizable (every section well commented)
- Animated Content
- Extremely easy to edit no need png all css SVG
- Preloader etc
- many more….

**FOR PERSONAL CACHE ONLY**

FROM: [http://themifycloud.com/downloads/freee-responsive-bootstrap-joli-angular-js-admin-template-dashboard-web-app/](http://themifycloud.com/downloads/freee-responsive-bootstrap-joli-angular-js-admin-template-dashboard-web-app/)
